import {Movie} from "./movie";
import {MovieService} from "./movieservice";
import {Component, OnInit} from '@angular/core';



@Component({
  selector: '<my-select></my-select>',
  templateUrl: './app.addMovie.html',
  providers: [MovieService, Movie]

})

export class AddMovie {

  mName: String;
  rating: number;
  genre: string;
  dateOfRelease: string;
  statusmessage:string;
  
  movie: Movie={
    
    name: null,
  rating: null,
  genre: null,
  dateOfRelease: null,
  
  };
  movieArray: Movie[];

  constructor(private movieSer: MovieService, private mov: Movie) {
  this.movie= mov;
  
  }




  add(): void {
 console.log(this.movie);
   
  this.movieSer.addMovie(this.movie).subscribe((movieData)=>this.movieArray=movieData,
   (error)=>{
                 this.statusmessage="Problem with service check server"
                    // console.error(error);
             }
    );     
   
   alert("Added");
    
    this.mName= null;
  this.rating=0;
  this.genre= null;
  this.dateOfRelease=null;
  }

}