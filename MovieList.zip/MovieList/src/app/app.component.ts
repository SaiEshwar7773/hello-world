import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.homePage.html'
})
export class AppComponent { name = 'Welcome Everyone '; }




