"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var movie_1 = require("./movie");
var movieservice_1 = require("./movieservice");
var core_1 = require("@angular/core");
var AddMovie = (function () {
    function AddMovie(movieSer, mov) {
        this.movieSer = movieSer;
        this.mov = mov;
        this.movie = {
            name: null,
            rating: null,
            genre: null,
            dateOfRelease: null,
        };
        this.movie = mov;
    }
    AddMovie.prototype.add = function () {
        var _this = this;
        console.log(this.movie);
        this.movieSer.addMovie(this.movie).subscribe(function (movieData) { return _this.movieArray = movieData; }, function (error) {
            _this.statusmessage = "Problem with service check server";
            // console.error(error);
        });
        alert("Added");
        this.mName = null;
        this.rating = 0;
        this.genre = null;
        this.dateOfRelease = null;
    };
    return AddMovie;
}());
AddMovie = __decorate([
    core_1.Component({
        selector: '<my-select></my-select>',
        templateUrl: './app.addMovie.html',
        providers: [movieservice_1.MovieService, movie_1.Movie]
    }),
    __metadata("design:paramtypes", [movieservice_1.MovieService, movie_1.Movie])
], AddMovie);
exports.AddMovie = AddMovie;
