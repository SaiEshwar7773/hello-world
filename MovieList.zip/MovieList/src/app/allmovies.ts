import {Movie} from "./movie";
import {MovieService} from "./movieservice";
import {Component, OnInit} from '@angular/core';

@Component({
  selector: '<my-select1></my-select1>',
  templateUrl: './app.allMovie.html',
  providers: [MovieService, Movie]

})

export class AllMovies implements OnInit {

 movie :Movie;
  movieArray:Movie[];
  
  constructor(private movser:MovieService){
   
     
  }
  
  
 ngOnInit():void{
   this.movser.getAll().subscribe(abc => {
   this.movieArray=abc;
   });
     
 }
  
  
  del(name:String):void{
    
   
    this.movser.del(name).subscribe(abc => {
   this.movieArray=abc;
   });
   
  }
  
  
  sortName():void{
    this.movieArray.sort(function(mov1: Movie, mov2 : Movie){
    
    if(mov1.name < mov2.name) return -1;
      
      else if(mov1.name > mov2.name) return 1;
      
      else
      return 0;
    
    }
    );
  }

  genres:String[]=[
  'Drama','Fiction','Action'
  ];
  genval:String;
 // Update code
   
     name1:String;
     rating1:Number;
     gener1: String;
  genresel:String;
     dateOfRelease1: String;
   
   upDate(movie: Movie):void{
         this.name1=movie.name;
     alert(movie.name);
     this.rating1= movie.rating;
     this.genval = movie.genre;
     this.dateOfRelease1= movie.dateOfRelease;
     
   }
  
 
   
 
   
   
  
  
}