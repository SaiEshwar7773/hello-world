"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var movie_1 = require("./movie");
var movieservice_1 = require("./movieservice");
var core_1 = require("@angular/core");
var AllMovies = (function () {
    function AllMovies(movser) {
        this.movser = movser;
        this.genres = [
            'Drama', 'Fiction', 'Action'
        ];
    }
    AllMovies.prototype.ngOnInit = function () {
        var _this = this;
        this.movser.getAll().subscribe(function (abc) {
            _this.movieArray = abc;
        });
    };
    AllMovies.prototype.del = function (name) {
        var _this = this;
        this.movser.del(name).subscribe(function (abc) {
            _this.movieArray = abc;
        });
    };
    AllMovies.prototype.sortName = function () {
        this.movieArray.sort(function (mov1, mov2) {
            if (mov1.name < mov2.name)
                return -1;
            else if (mov1.name > mov2.name)
                return 1;
            else
                return 0;
        });
    };
    AllMovies.prototype.upDate = function (movie) {
        this.name1 = movie.name;
        alert(movie.name);
        this.rating1 = movie.rating;
        this.genval = movie.genre;
        this.dateOfRelease1 = movie.dateOfRelease;
    };
    return AllMovies;
}());
AllMovies = __decorate([
    core_1.Component({
        selector: '<my-select1></my-select1>',
        templateUrl: './app.allMovie.html',
        providers: [movieservice_1.MovieService, movie_1.Movie]
    }),
    __metadata("design:paramtypes", [movieservice_1.MovieService])
], AllMovies);
exports.AllMovies = AllMovies;
