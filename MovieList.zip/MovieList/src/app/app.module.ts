import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent }  from './app.component';
import {HttpModule} from '@angular/http';
import {Routes, RouterModule} from '@angular/router';

import {AddMovie} from './addmovie';
import {AllMovies} from './allmovies';
import {Search} from"./search";


const appRoutes: Routes=[

      {path: 'addMovie', component:AddMovie},
  {path: 'allMovies', component: AllMovies}

];


@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(appRoutes) ],
  declarations: [ AppComponent ,AddMovie, AllMovies,Search],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
