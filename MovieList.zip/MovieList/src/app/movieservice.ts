import {Injectable} from '@angular/core';
import {Movie} from './movie'

import {Http, Response, Headers, RequestOptions} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import "rxjs/add/operator/map"
import "rxjs/add/operator/catch"

//No @Component in Service calss


@Injectable()
export class MovieService {

  constructor(private http: Http) {

  }

   handleError(error: Response){
        console.error(error);
        return Observable.throw(error);
    }

  addMovie(movie: Movie): Observable<Movie[]> {
    let mov = JSON.stringify(movie);
    let cpHeaders = new Headers({'Content-type': 'application/json'})
    let options = new RequestOptions({headers: cpHeaders});
    return this.http
      .post('http://localhost:8081/MovieLab/rest/add/', mov, options)
      .map((response: Response) => <Movie[]>response.json())
      .catch(this.handleError);

  }
  
  
  getAll():Observable<Movie[]>{
    
    return this.http.get("http://localhost:8081/MovieLab/rest/getAll").
        map((response:Response)=><Movie[]>response.json())
        .catch(this.handleError);
  }

  del(name:String):Observable<Movie[]>{
     
    
   return this.http.delete("http://localhost:8081/MovieLab/rest/delete/" + name).
    map((response: Response) => <Movie[]>response.json())
      .catch(this.handleError);
    
  
   
    
  }
  
  
}