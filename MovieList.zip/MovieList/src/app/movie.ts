import { Injectable } from "@angular/core";

@Injectable()
export class Movie {
    
    name:String;
    rating:Number;
    genre:String;
    dateOfRelease:string;
  
}