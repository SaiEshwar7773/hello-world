import {  Pipe, PipeTransform }      from '@angular/core';


@Pipe({
  name: 'searchPipe'
  
})

export class Search implements PipeTransform {
  
  transform(movies:any, search: any):any{
    if(search==undefined)return movies;
    
    return movies.filter(function(movies:any){
      return movies.name.toLowerCase().includes(search.toLowerCase());
    })
  }
  
}