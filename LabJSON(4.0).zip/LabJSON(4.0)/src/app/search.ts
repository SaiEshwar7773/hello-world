
import {PipeTransform,Pipe} from 'angular2/core';
import {IEmpoyee} from "./app/employee"

@Pipe({  name : 'searchPipe'})



export class Search implements PipeTransform{
  
  transform(book: any ,search : any):any{
    
    if(search=undefined) return book;
    
   
    
           return book.filter(function(book:any){
               console.log(book);
               return book.title.toLowerCase().includes(search.toLowerCase());
           })
    
    
    
  }
  
  
}