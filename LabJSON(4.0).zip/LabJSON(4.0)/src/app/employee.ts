export interface IEmployee{
    bookID: number;
    bookTitle:string;
    bookAuthor : string;
    bookYear : number;

}