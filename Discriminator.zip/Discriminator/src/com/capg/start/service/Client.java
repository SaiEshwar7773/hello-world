package com.capg.start.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capg.start.entities.NonTechnicalStaff;
import com.capg.start.entities.TechnicalStaff;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Discriminator");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		TechnicalStaff ts1 = new TechnicalStaff(1, "Maniiiiish", 25, "MTech", "Digital Electronics");
		TechnicalStaff ts2 = new TechnicalStaff(2, "Harish", 35, "Phd.", "Communication");
		
		NonTechnicalStaff nts1 = new NonTechnicalStaff(3, "Aman", 45, "Office Admin");
		NonTechnicalStaff nts2 = new NonTechnicalStaff(4, "Sai", 21, "Consultant");
		
		em.persist(ts1);
		em.persist(nts1);
		em.persist(nts2);
		em.persist(ts2);
		
		System.out.println("Added");
		em.getTransaction().commit();
		em.close();
		emf.close();

	}

}
