package com.capg.start.entities;

import com.capg.start.entities.Staff;

import java.io.Serializable;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: NonTechnicalStaff
 *
 */
@Entity

public class NonTechnicalStaff extends Staff implements Serializable {

	
	private static final long serialVersionUID = 1L;

	private String areaExpertise;
	
	public NonTechnicalStaff(int id, String name, int age, String area){
		super(id,name,age);
		this.areaExpertise=area;
	}
	
	public NonTechnicalStaff() {
		super();
	}

	public String getAreaExpertise() {
		return areaExpertise;
	}

	public void setAreaExpertise(String areaExpertise) {
		this.areaExpertise = areaExpertise;
	}
   
}
