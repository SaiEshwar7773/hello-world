package com.capg.start.entities;

import com.capg.start.entities.Staff;

import java.io.Serializable;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: TechniacalStaff
 *
 */
@Entity

public class TechnicalStaff extends Staff implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	private String qualification;
	private String subjectExpertise;
	
	public TechnicalStaff(int id, String name, int age, String qual, String subject){
		super(id,name,age);
		this.qualification = qual;
		this.subjectExpertise = subject;
	}
	

	public TechnicalStaff() {
		super();
	}

	public String getQualification() {
		return qualification;
	}



	public void setQualification(String qualification) {
		this.qualification = qualification;
	}



	public String getSubjectExpertise() {
		return subjectExpertise;
	}



	public void setSubjectExpertise(String subjectExpertise) {
		this.subjectExpertise = subjectExpertise;
	}



   
}
