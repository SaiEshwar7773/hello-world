import {Component,OnInit} from '@angular/core';
import {Employee} from './employee';
import {EmployeeService} from './employee.service';
import { Movie } from "./app.movie";

@Component({
    selector:'<my-select></my-select>',
    templateUrl:'./app.select.html',
    providers:[EmployeeService, Movie],
    
    
})


export class Select {
    
    name:String;
    rating:Number;
    genre:String;
    employees:Employee[];
    statusmessage:string;
    movie:Movie;

  mo:Movie[];   
               



constructor(private empservice:EmployeeService, private mov:Movie) {
    
    this.movie = mov;
    
}

 addBook()
 {
 
     //this.employees:Employee[]=[{}];
     
    this.movie.name = this.name;
    this.movie.rating = this.rating;
    this.movie.genre = this.genre;
     
    
    this.mo=[{ name:this.name,
        rating:this.rating,
        genre:this.genre
}
        ];      
        
     this.empservice.addBook(this.movie).subscribe((employeeData)=>this.employees=employeeData,
             (error)=>{
                 this.statusmessage="Problem with service check server"
                    // console.error(error);
             }    
             );
   
      this.name = "";
      this.rating = null;
      this.genre = "";
      
     alert("Data Added");
   
    console.log("Return : "+this.employees);
   
 }
    
    
}