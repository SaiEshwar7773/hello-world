import { Component } from '@angular/core';
import { Router } from '@angular/router'; 

@Component({
  selector: 'my-app',
  templateUrl:'./app.display.html'
  
})
export class AppComponent { 
    name = 'Welcome Angular 2'; 







}
