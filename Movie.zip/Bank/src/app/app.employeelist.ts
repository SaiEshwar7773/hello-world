import {Component,OnInit} from '@angular/core';
import {Employee} from './employee';
import {EmployeeService} from './employee.service';
//import { Department } from "./Department";

@Component({
    selector:'<my-component></my-component>',
    templateUrl:'./app.employeecomponent.html',
    providers:[EmployeeService]
})
export class EmployeeList implements  OnInit{
    
    employees:Employee[];
    statusmessage:string;
    option:String;
    status:boolean=false;

constructor(private empservice:EmployeeService) {}
ngOnInit(): void {
   
      
   }


delete(id:String):void{
   
    this.status=true;
    this.empservice.getBooks(id).subscribe((employeeData)=>this.employees=employeeData,
            (error)=>{
                this.statusmessage="Problem with service check server"
                   // console.error(error);
            }    
            );
    
    console.log(this.employees);
}


            
    
}